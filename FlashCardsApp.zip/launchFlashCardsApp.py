import os
os.system('java --module-path FlashCardsApp_lib --add-modules javafx.controls,javafx.fxml --enable-preview -jar FlashCardsApp.jar')